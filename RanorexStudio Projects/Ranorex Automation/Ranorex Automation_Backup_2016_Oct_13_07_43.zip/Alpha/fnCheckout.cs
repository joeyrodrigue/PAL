﻿/*
 * Created by Ranorex
 * User: storeuser
 * Date: 02/10/15
 * Time: 6:37 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace Alpha
{
    /// <summary>
    /// Description of FnCheckout.
    /// </summary>
    [TestModule("1181A006-37DD-4A71-A038-DF70DC5C32B3", ModuleType.UserCode, 1)]
    public class FnCheckout : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public FnCheckout()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
        }
        
        public void Run()
        {	
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;    
            
			Ranorex.Unknown element = null;            
            
        	RanorexRepository repo = new RanorexRepository(); 
        	fnWriteToLogFile WriteToLogFile = new fnWriteToLogFile();
        	fnTimeMinusOverhead TimeMinusOverhead = new fnTimeMinusOverhead();
        	fnDumpStatsQ4 DumpStatsQ4 = new fnDumpStatsQ4(); 
        	fnWriteToErrorFile WriteToErrorFile = new fnWriteToErrorFile();
        	
           	// Create new stopwatch
			Stopwatch MystopwatchTT = new Stopwatch();	
			MystopwatchTT.Reset();	
			MystopwatchTT.Start();	
			
			Stopwatch MystopwatchTotal = new Stopwatch();	
			MystopwatchTotal.Reset();
			MystopwatchTotal.Start();
			Stopwatch MystopwatchQ4 = new Stopwatch();	
			Stopwatch MystopwatchModuleTotal = new Stopwatch();	
			Stopwatch MystopwatchF1 = new Stopwatch();	
			Stopwatch MystopwatchTrade = new Stopwatch();	        	
        	
        	Global.LogFileIndentLevel++;
        	Global.LogText = "IN fnCheckout";
			WriteToLogFile.Run();	  
			
			MystopwatchModuleTotal.Reset();	
			MystopwatchModuleTotal.Start();	 			

			// Click on CheckOut F12 button
			Global.LogText = @"Clicking on F12 Checkout";
			WriteToLogFile.Run(); 
			
            MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start();	
			
			while(!repo.Retech.ButtonCheckout.Enabled)
			{ Thread.Sleep(100); }
			Keyboard.Press("{F12}");
			Thread.Sleep(1000);		

			// Check for Please select a charity to donate
			if(Host.Local.TryFindSingle(repo.RetechPeripheralHostWindow.PleaseSelectACharityToDonateInfo.AbsolutePath.ToString(), out element))
			{
				repo.RetechPeripheralHostWindow.DeclineDonateNoThanks.Click();
				Thread.Sleep(100);
			}

			Global.LogText = @"Waiting on Time to Check Out";
			WriteToLogFile.Run();		
			while(!Host.Local.TryFindSingle(repo.Retech.TimeToCheckOutInfo.AbsolutePath.ToString(), out element))
			{	
//				Thread.Sleep(100);
//				if(Host.Local.TryFindSingle(repo.EmailReceiptView.DeclineCommandInfo.AbsolutePath.ToString(), out element))				
//				{
//					Global.LogText = @"Clicking on Decline command";
//					WriteToLogFile.Run();						
//					repo.EmailReceiptView.DeclineCommand.Click();
//					Thread.Sleep(100);						
//				}				
				if(Host.Local.TryFindSingle(repo.Retech.AcknowledgeRelatedProductsCommandInfo.AbsolutePath.ToString(), out element))
				{
					if(repo.Retech.AcknowledgeRelatedProductsCommand.Enabled)
					{
						Global.LogText = @"Clicking on acknowledge related products before F12";
						WriteToLogFile.Run();						
						repo.Retech.AcknowledgeRelatedProductsCommand.Click();
						Thread.Sleep(100);						
					}
				}					
				else if(Host.Local.TryFindSingle(repo.Retech.ContinueF5_5_6_0_103Info.AbsolutePath.ToString(), out element))
				{
					if(repo.Retech.ContinueF5_5_6_0_103.Enabled)
					{
						Global.LogText = @"Clicking on F5 Continue before F12";
						WriteToLogFile.Run();						
						repo.Retech.ContinueF5_5_6_0_103.Click();
						Thread.Sleep(100);	
						repo.Retech.ButtonCheckout.Click();
						Thread.Sleep(100);
					}
				}
			}

			TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
            Global.CurrentMetricDesciption = @"[F12] wait for payment icons";
            Global.Module = "Finalize";                
            DumpStatsQ4.Run();     	
            
            MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start();	           

			// Click on screen to make sure in focust - .focus not work
			repo.Retech.PaymentView.Click("689;82");
			
	     	switch (Global.PayWithMethod) 
	     	{			
	     		case "Cash": 
					Global.LogText = @"Waiting on Cash F5";
					WriteToLogFile.Run();			
					repo.Retech.Self.Focus();
					Thread.Sleep(100);
					while(!repo.Retech.RequestCashSettlement.Enabled)
					{	Thread.Sleep(500); } 
					Global.LogText = @"Found Cash F5 Enabled";
					WriteToLogFile.Run();	     			
	     			break; 			
	     		case "Credit":
	     		case "PURCC":	     			
					Global.LogText = @"Waiting on Manual Card F6";
					WriteToLogFile.Run();			
					repo.Retech.Self.Focus();
					Thread.Sleep(100);
					while(!repo.Retech.RequestManualCardSettlement.Enabled)
					{	Thread.Sleep(500);	}					
					Global.LogText = @"Found Manual Card F6 Enabled";
					WriteToLogFile.Run();		     			
	     			break;
	     	}

	     	// Check for cash back
	     	if (repo.Retech.AmountDue.TextValue.Substring(0,1) == "("
	     	    && ( Global.CurrentScenario == 37 || Global.CurrentScenario == 47 )
	     	   )
	     	{
				Global.LogText = @"Clicking on Cash F5 button";
				WriteToLogFile.Run(); 	
				repo.Retech.RequestCashSettlement.Click();
				Thread.Sleep(100);
				while(!repo.RetechCardPaymentView.CashPaymentView.Enabled)
				{	Thread.Sleep(100);	}
				Keyboard.Press("{Enter}");				
	     	}
	     	else
	     	{
				// Read Remaining Balance from screen
				string BalanceDueText = repo.Retech.BalanceDue.TextValue;
				string BalTemp = BalanceDueText.Substring(1,BalanceDueText.Length - 1);
				float BalanceDueAmount = float.Parse(BalTemp);
				string BalanceDueAmountTxt = Convert.ToString(BalanceDueAmount);			
	
		     	switch (Global.PayWithMethod) 
		     	{
		     		case "Cash":	     			
						// Click on Cash F5 button
						Global.LogText = @"Clicking on Cash F5 button";
						WriteToLogFile.Run(); 						
						repo.Retech.RequestCashSettlement.Click();
						while(!Host.Local.TryFindSingle(repo.RetechCardPaymentView.TxtAmountPaidInfo.AbsolutePath.ToString(), out element) )
						{	
							Thread.Sleep(100);
						}
						
						// Enter amount paid
						repo.RetechCardPaymentView.TxtAmountPaid.TextValue = BalanceDueAmountTxt;
						repo.RetechCardPaymentView.TxtAmountPaid.PressKeys("{Enter}");	  	
						
						TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
			            Global.CurrentMetricDesciption = @"[F5] enter amount press Enter";
			            Global.Module = "Finalize";                
			            DumpStatsQ4.Run();     	

			     		break;	 
		     			
		     		case "Credit":
						// Click on Manual Card F6 button
						Global.LogText = @"Clicking on Manual Card F6 button";
						WriteToLogFile.Run(); 	
						repo.Retech.RequestManualCardSettlement.Click();
						
						while(!repo.RetechCardPaymentView.RunAsCreditCard.Enabled)
						{
							if(!Host.Local.TryFindSingle(repo.RetechCardPaymentView.RetrySameCardInfo.AbsolutePath.ToString(), out element))
							{
								Global.LogText = @"Clicking on Retry same card";
								WriteToLogFile.Run(); 	
								Global.TempErrorString = Global.LogText;
								WriteToErrorFile.Run();								
								repo.RetechCardPaymentView.RetrySameCard.Click();
								Thread.Sleep(200);
							}
							Thread.Sleep(100);
						}
						
						// Click on Run as Credit button
						Global.LogText = @"Clicking on Run as Credit button";
						WriteToLogFile.Run(); 		
						repo.RetechCardPaymentView.RunAsCreditCard.Click();

						
						string RetechVersion = Global.RetechVersion;
						string Sub = Global.RetechVersion.Substring(0,4);
//						if(Global.RetechVersion.Substring(0,4) != "5.14")
						if(Global.RetechVersion.Substring(0,4) == "5.13")
						{	// ### For Retech 5.13 and below - see else code for Retech 5.14
							while(!repo.RetechCardPaymentView.TxtCardNumber.Enabled)
							{
								if(Host.Local.TryFindSingle(repo.RetechCardPaymentView.RetrySameCardInfo.AbsolutePath.ToString(), out element))							
								{
									repo.RetechCardPaymentView.RetrySameCard.Click();
									Thread.Sleep(200);
								}
								Thread.Sleep(100);
							}
	
	//						Thread.Sleep(500);
		
							repo.RetechCardPaymentView.TxtCardNumber.TextValue = Global.CreditCardNumber;
							string aa = Global.CreditCardMonth + "/" + Global.CreditCardYear;
							repo.RetechCardPaymentView.TxtExpirationDate.TextValue = Global.CreditCardMonth + "/" + Global.CreditCardYear;
							repo.RetechCardPaymentView.TxtZipCode.TextValue = Global.CreditCardZip; 
		
							repo.RetechCardPaymentView.ProcessCreditCardView.PressKeys("{Enter}");
	//						Thread.Sleep(100);
							
							while(!Global.AbortScenario && 
							      !Host.Local.TryFindSingle(repo.RetechCardPaymentView.Waiting_for_SignatureInfo.AbsolutePath.ToString(), out element))						
							
							{	
								Thread.Sleep(100);	
								if(Host.Local.TryFindSingle(repo.RetechCardPaymentView.TryAuthorizingAgainInfo.AbsolutePath.ToString(), out element) )						
								{
									Global.AbortScenario = true;
									Global.TempErrorString = "Credit Card Unable to Process Payment - transaction voided";
									WriteToErrorFile.Run();
									Global.LogText = Global.TempErrorString;
									WriteToLogFile.Run();	
									Keyboard.Press("{Escape}");
									Thread.Sleep(100);
									repo.Retech.DataContextVoidOrderCommand.Click();
									Thread.Sleep(100);
									repo.GenericDialogView.Yesvoidthistransaction.Click();
									Thread.Sleep(100);
									while(!repo.RetechAnotherTransaction.Visible)
									{	Thread.Sleep(100);	}
								}
								
							}
						}
						else
						{	// ### This required for Retech 5.14 and above because Ranorex not see detail of new pinpad
				            repo.RetechPeripheralHostWindow.TabControl.Click("189;453");

				            repo.RetechPeripheralHostWindow.TabControl.Click("31;84");
				            
				            Keyboard.Press(Global.CreditCardNumber);
				            
				            repo.RetechPeripheralHostWindow.TabControl.Click("157;472");
				            
				            repo.RetechPeripheralHostWindow.TabControl.Click("44;115");
				            
				            Keyboard.Press(Global.CreditCardMonth + "{Tab}" + Global.CreditCardYear);
				            Thread.Sleep(200);
				            repo.RetechPeripheralHostWindow.TabControl.Click("93;466");
				            Thread.Sleep(200);
				            repo.RetechPeripheralHostWindow.TabControl.Click("40;126");
				            Thread.Sleep(200);
				            Keyboard.Press(Global.CreditCardZip);
						            
				            repo.RetechPeripheralHostWindow.TabControl.Click("155;445");
				            Thread.Sleep(100);
						}
						
						TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
			            Global.CurrentMetricDesciption = @"[F6] enter Card info";
			            Global.Module = "Finalize";                
			            DumpStatsQ4.Run(); 
			            
					    MystopwatchQ4.Reset();	    
						MystopwatchQ4.Start();	 				            
						
						if(!Global.AbortScenario)
						{
							repo.RetechPeripheralHostWindow.SignOnPinPad.Click();
							Thread.Sleep(200);
							repo.RetechPeripheralHostWindow.AcceptOnPinPad.Click();
							Thread.Sleep(200);
							repo.RetechCardPaymentView.Self.Focus();
							Thread.Sleep(100);
							repo.RetechCardPaymentView.SignatureAcceptedCommand.Click();
							Thread.Sleep(200);		
							
							TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
				            Global.CurrentMetricDesciption = @"Sign on pin pad";
				            Global.Module = "Finalize";                
				            DumpStatsQ4.Run(); 							
						}					

		     			break;	
		     			
		     		case "PURCC":
						// Click on Manual Card F6 button
						Global.LogText = @"Clicking on Manual Card F6 button";
						WriteToLogFile.Run(); 	
						repo.Retech.RequestManualCardSettlement.Click();
						while(!repo.RetechCardPaymentView.RunAsPURCCCard.Enabled)
						{
							Thread.Sleep(100);
						}
			
						// Click on Run as PURCC button (Run as PowerUp Rewards Cerdit Cart
						Global.LogText = @"Clicking on run as PURCC";
						WriteToLogFile.Run(); 						
						repo.RetechCardPaymentView.RunAsPURCCCard.Click();
						while(!Host.Local.TryFindSingle(repo.RetechCardPaymentView.TxtCardNumberInfo.AbsolutePath.ToString(), out element) )
						{	Thread.Sleep(100);	}		
						
						// Select ID type and Issuer (Drivers Lenense and State)
						repo.RetechCardPaymentView.PickIdType.SelectedItemText = "Drivers License";
						repo.RetechCardPaymentView.PickIdIssuer.Click();
						repo.RetechCardPaymentView.PickIdIssuer.SelectedItemText = "Texas";
						repo.RetechCardPaymentView.ProcessPrivateLabelCreditCardView.Click();
	
						// Fill in PowerUp Rewards Credit Card Manual Entry
						repo.RetechCardPaymentView.TxtCardNumber.TextValue = "7788400030000272";
						repo.RetechCardPaymentView.TxtNameFromId.TextValue = "PAL User";	
						repo.RetechCardPaymentView.ProcessPrivateLabelCreditCardView.Click();
						repo.RetechCardPaymentView.Self.PressKeys("{Enter}");
	
						Global.LogText = @"Info entered - watching for Waiting for Signature";
						WriteToLogFile.Run();
	
						while(!Global.AbortScenario && 
						      !Host.Local.TryFindSingle(repo.RetechCardPaymentView.Waiting_for_SignatureInfo.AbsolutePath.ToString(), out element))						
						{	
							Thread.Sleep(100);	
							if(Host.Local.TryFindSingle(repo.RetechCardPaymentView.PaymentCouldNotBeAuthorizedAnUnknInfo.AbsolutePath.ToString(), out element) )						
							{
								Global.AbortScenario = true;
								Global.TempErrorString = "PURCC Unable to Process Payment - transaction voided";
								WriteToErrorFile.Run();
								Global.LogText = Global.TempErrorString;
								WriteToLogFile.Run();	
								Keyboard.Press("{Escape}");
								Thread.Sleep(100);
								repo.Retech.DataContextVoidOrderCommand.Click();
								Thread.Sleep(100);
								repo.GenericDialogView.Yesvoidthistransaction.Click();
								Thread.Sleep(100);
								while(!repo.RetechAnotherTransaction.Visible)
								{	Thread.Sleep(100);	}
							}
						}
						if(!Global.AbortScenario)
						{
							repo.RetechPeripheralHostWindow.SignOnPinPad.Click();
							Thread.Sleep(200);
							repo.RetechPeripheralHostWindow.AcceptOnPinPad.Click();
							Thread.Sleep(200);
							repo.RetechCardPaymentView.Self.Focus();
							Thread.Sleep(100);
							repo.RetechCardPaymentView.SignatureAcceptedCommand.Click();
							Thread.Sleep(200);						
						}
		     			break;
		     	}	
		     	
			            
			    MystopwatchQ4.Reset();	    
				MystopwatchQ4.Start();	 		     	
	
				// Wait for Another Transaction pop-up
				while(!Host.Local.TryFindSingle(repo.RetechAnotherTransactionInfo.AbsolutePath.ToString(), out element) )
				{	
					Thread.Sleep(100);
					if(Host.Local.TryFindSingle(repo.RetechTillOverageWarningView.CodeF4AlertInfo.AbsolutePath.ToString(), out element)
					  	||
					   Host.Local.TryFindSingle(repo.RetechTillOverageWarningView.CodeF4Alert2Info.AbsolutePath.ToString(), out element)
					  )
					{
						GlobalOverhead.Stopwatch.Start();					
						repo.RetechTillOverageWarningView.DropCashCommand.Click();
						while(!repo.RetechLoginView.TxtPassword.Enabled)
						{	Thread.Sleep(100);	}						
			          		repo.RetechLoginView.TxtPassword.PressKeys("advanced{Return}");
						while(!repo.RetechTillDepositView.DropBoxAmount.Enabled)
						{	Thread.Sleep(100);	}	            		
			          		repo.RetechTillDepositView.DropBoxAmount.PressKeys("20000");  
			          		repo.RetechTillDepositView.AddCashDropButton.Click();
			          		Thread.Sleep(1000);
			          		repo.RetechTillDepositView.DropBoxAmount.PressKeys("{Escape}");  
						GlobalOverhead.Stopwatch.Stop();            		
					}
				}		

	     	}
	     	
			TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
			Global.CurrentMetricDesciption = @"Wait for another transaction ESC";
			Global.Module = "Finalize";                
			DumpStatsQ4.Run();  
			
			switch (Global.PayWithMethod)
			{
				case "Cash":
					Global.NowPayWithCash = Global.AdjustedTime;			     			
					break;
				case "Credit":
					Global.NowPayWithCredit = Global.AdjustedTime;			     			
					break;
				case "PURCC":	
					Global.NowPayWithPURCC = Global.AdjustedTime;		     			
					break;
			}			
			            
			MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start();	 	     	

			// Press excape key on Another Transaction pop-up
			while(!Host.Local.TryFindSingle(repo.RetechLoginView.TxtPasswordInfo.AbsolutePath.ToString(), out element) )
			{	Thread.Sleep(100);	}		
			repo.RetechLoginView.TxtPassword.PressKeys("{Escape}");    

			
            TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
            Global.CurrentMetricDesciption = "Wait for Sart a Transaction ESC";
            Global.Module = "Finalize";                   
            DumpStatsQ4.Run();  			
			
            TimeMinusOverhead.Run((float) MystopwatchModuleTotal.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
            Global.CurrentMetricDesciption = "Module Total Time";
            Global.Module = "Finalize";                   
            DumpStatsQ4.Run();   			

			Global.LogText = "OUT fnCheckout";
			WriteToLogFile.Run();	
			Global.LogFileIndentLevel--;        	
	
        }      
        

    }
}
