﻿/*
 * Created by Ranorex
 * User: storeuser
 * Date: 06/02/15
 * Time: 6:18 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace Alpha
{
    /// <summary>
    /// Description of FnCommonScenario14and15.
    /// </summary>
    [TestModule("8ADAA63D-642B-49E8-8AFB-2EFDDAC50873", ModuleType.UserCode, 1)]
    public class FnCommon14and15 : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public FnCommon14and15()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
        }
        
        public void Run()
        {	
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;    
            
			Ranorex.Unknown element = null;             
			
        	RanorexRepository repo = new RanorexRepository();
        	fnUpdatePALStatusMonitor UpdatePALStatusMonitor = new fnUpdatePALStatusMonitor();  
        	fnWriteToLogFile WriteToLogFile = new fnWriteToLogFile();
        	FnWriteOutStatsQ4Buffer WriteOutStatsQ4Buffer = new FnWriteOutStatsQ4Buffer();
        	fnDumpStatsQ4 DumpStatsQ4 = new fnDumpStatsQ4();
        	fnTimeMinusOverhead TimeMinusOverhead = new fnTimeMinusOverhead(); 
			fnWriteToErrorFile WriteToErrorFile = new fnWriteToErrorFile();  			
			
			Stopwatch MystopwatchQ4 = new Stopwatch();	
			Stopwatch MystopwatchTT = new Stopwatch();	
			
           	MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start(); 
			
			
			Global.LogText = @"Waiting for Performance Dashboard to display";
			WriteToLogFile.Run();	
			
            while(!repo.ShellRoot.DashboardSalesDollar.Visible)
            {	Thread.Sleep(100);
            }

			Global.TempFloat = (float) MystopwatchQ4.ElapsedMilliseconds / 1000;
			TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
            Global.CurrentMetricDesciption = "Display Store F1 default report";
            Global.Module = "Dashboard:";                
            DumpStatsQ4.Run();   	           
            
           	MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start();             
            
			Global.LogText = @"Waiting for Performance Dashboard Employee F2 to display";
			WriteToLogFile.Run();	
			repo.ShellRoot.EmployeeF2.Click();
            MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start();  
			while(!Host.Local.TryFindSingle(repo.ShellRoot.LeaderBoardDollarInfo.AbsolutePath.ToString(), out element))
			{  Thread.Sleep(100);  }			
            while(!repo.ShellRoot.LeaderBoardDollar.Visible)
            {	Thread.Sleep(100);
            }            
			Global.TempFloat = (float) MystopwatchQ4.ElapsedMilliseconds / 1000;
			TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
            Global.CurrentMetricDesciption = "Display Employee F2 report";
            Global.Module = "Dashboard:";                
            DumpStatsQ4.Run();      
            
           	MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start();                  
            
			Global.LogText = @"Waiting for Performance Dashboard Reports F3 to display";
			WriteToLogFile.Run();	           
			repo.ShellRoot.ReportsF3.Click();
            MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start();  			
            while(!repo.ShellRoot.ReportsF3Dollar.Visible)
            {	Thread.Sleep(100);
            }            
			Global.TempFloat = (float) MystopwatchQ4.ElapsedMilliseconds / 1000;
			TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
            Global.CurrentMetricDesciption = @"Display Report F3 report";
            Global.Module = "Dashboard:";                
            DumpStatsQ4.Run();              
            
            
			Global.LogText = @"Waiting for Performance Dashboard Goals F4 to display";
			WriteToLogFile.Run();	           
			repo.ShellRoot.GoalsF4.Click();
			
            MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start();  
			
			switch (Global.RetechVersion.Substring(0,3))
			{
				case "5.6":
		            while(!repo.ShellRoot.GoalsF4Dollar_5_6_0_103.Visible)
		            {	Thread.Sleep(100);   }     				
					break;
				case "5.7":
		            while(!repo.ShellRoot.GoalsF4Dollar_5_7_1_2.Visible)
		            {	Thread.Sleep(100);   }     			
					break;	
				default:
		            while(!repo.ShellRoot.GoalsF4Dollar_5_7_1_2.Visible)
		            {	Thread.Sleep(100);   }     				
					break;						
			}					

			Global.TempFloat = (float) MystopwatchQ4.ElapsedMilliseconds / 1000;
			TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
            Global.CurrentMetricDesciption = "Display Goals F4 report";
            Global.Module = "Dashboard:";
            DumpStatsQ4.Run();               

        }
    }
}
