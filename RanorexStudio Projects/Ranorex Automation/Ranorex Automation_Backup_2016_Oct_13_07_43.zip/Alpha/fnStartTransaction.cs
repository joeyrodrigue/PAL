﻿/*
 * Created by Ranorex
 * User: storeuser
 * Date: 02/19/15
 * Time: 2:21 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace Alpha
{
    /// <summary>
    /// Description of FnStartTransaction.
    /// </summary>
    [TestModule("D06C80B6-AB80-4A4F-949D-6EB8E7C66D2C", ModuleType.UserCode, 1)]
    public class FnStartTransaction : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public FnStartTransaction()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
        }
        
        public void Run()
        {	
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;    
            
			Ranorex.Unknown element = null;            
            
        	RanorexRepository repo = new RanorexRepository(); 
        	fnWriteToLogFile WriteToLogFile = new fnWriteToLogFile();
        	fnTimeMinusOverhead TimeMinusOverhead = new fnTimeMinusOverhead();
        	fnDumpStatsQ4 DumpStatsQ4 = new fnDumpStatsQ4(); 
        	fnWriteToErrorFile WriteToErrorFile = new fnWriteToErrorFile();   
        	
           	// Create new stopwatch
			Stopwatch MystopwatchTT = new Stopwatch();	
			MystopwatchTT.Reset();	
			MystopwatchTT.Start();	

			Stopwatch MystopwatchF1 = new Stopwatch();	
			Stopwatch MystopwatchQ4 = new Stopwatch();	
			Stopwatch MystopwatchModuleTotal = new Stopwatch();
			MystopwatchModuleTotal.Reset();	
			MystopwatchModuleTotal.Start();	       	

			Global.LogText = @"Start Transaction";
			WriteToLogFile.Run(); 	

			MystopwatchQ4.Reset();	
			MystopwatchQ4.Start();					
			
            // Click on start a transaction
            while(!Host.Local.TryFindSingle(repo.Retech.StartATransactionInfo.AbsolutePath.ToString(), out element))
            {
            	Thread.Sleep(100);
            }
            repo.Retech.StartATransaction.Click();
			if(Host.Local.TryFindSingle(repo.GenericDialogView.CriticalErrorSavingTransactionCallHInfo.AbsolutePath.ToString(), out element))	
			{
				repo.GenericDialogView.ErrorSavingButtonOK.Click();
				Thread.Sleep(200);
				Global.TempErrorString = "Error Saving Transaction";
				WriteToErrorFile.Run();
				Global.LogText = Global.TempErrorString;
				WriteToLogFile.Run();	
			}		            
			MystopwatchF1.Reset();
			MystopwatchF1.Start();
			while(!Host.Local.TryFindSingle(repo.RetechLoginView.TxtPasswordInfo.AbsolutePath.ToString(), out element))			
			{	
            	Thread.Sleep(100);	
				if(MystopwatchF1.ElapsedMilliseconds > 1500)
				{
					repo.Retech.StartATransaction.Click();
					MystopwatchF1.Reset();	
					MystopwatchF1.Start();	
				}   
				if(Host.Local.TryFindSingle(repo.GenericDialogView.CriticalErrorSavingTransactionCallHInfo.AbsolutePath.ToString(), out element))	
				{
					repo.GenericDialogView.ErrorSavingButtonOK.Click();
					Thread.Sleep(200);
					Global.TempErrorString = "Error Saving Transaction";
					WriteToErrorFile.Run();
					Global.LogText = Global.TempErrorString;
					WriteToLogFile.Run();	
				}				
            } 
			Global.TempFloat = (float) MystopwatchQ4.ElapsedMilliseconds / 1000;
			TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
            Global.CurrentMetricDesciption = @"[F5] Start Transaction";
            Global.Module = "Log On";                
            DumpStatsQ4.Run();              
            
			// Enter Password
            MystopwatchQ4.Reset();	    
			MystopwatchQ4.Start();	 			
        
			repo.RetechLoginView.TxtPassword.PressKeys("advanced{Return}");
			
			switch (Global.RetechVersion.Substring(0,3))
			{
				case "5.6":
           			while(!repo.Retech.LetsGetStarted_5_6_0_103.Visible)
					{	Thread.Sleep(100);	}  					
					break;
				case "5.7":
           			while(!repo.Retech.AddLineItemCommand.Enabled)
					{	Thread.Sleep(100);	}  					
					break;	
				default:
           			while(!repo.Retech.AddLineItemCommand.Enabled)
					{	Thread.Sleep(100);	}  					
					break;						
			}

			TimeMinusOverhead.Run((float) MystopwatchQ4.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine            
            Global.CurrentMetricDesciption = "Enter Password";
            Global.Module = "Log On";                
            DumpStatsQ4.Run();          
            
            TimeMinusOverhead.Run((float) MystopwatchModuleTotal.ElapsedMilliseconds);  // Subtract overhead and store in Global.Q4StatLine
            Global.CurrentMetricDesciption = "Module Total Time";
            Global.Module = "Log On";                   
            DumpStatsQ4.Run();   
         	
        }
        
    }
}
